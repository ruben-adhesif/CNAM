Bonjour Monsieur,
Voici ma premiere version de l'OCR. Ce n'est qu'en phase de test.
J'utilise pour cela l'OCR de google Tesseract et plus précisement son portage par une université allemande sur Python.
Pour le moment je test avec un texte simple en anglais 'OCR_eng.png'.
Mais j'ai un problème que je ne comprends pas et sur lequel je me casse les dents depuis quelques jours. J'ai un problème d'autorisation, de variable d'environnement qui crée de nombreux bug et qui m'empêchent d'utiliser les config 'psm' et 'oem'.
Pouvez vous m'aider s'il vous plait ?
Cordialement